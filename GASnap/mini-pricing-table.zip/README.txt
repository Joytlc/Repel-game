A Pen created at CodePen.io. You can find this one at https://codepen.io/joejoinerr/pen/CJAkK.

 Working version of Cosmin Negoita's Mini Pricing Table. Now in BEM syntax. PSD available here: http://365psd.com/day/3-137/